@extends('layouts.admin') ;

@section('content')


<h3><i class="fa fa-angle-right"></i> Package Details</h3>
        
<div class="panel panel-default">
  <div class="panel-heading">
      Category Name: {{$package->name}}
  </div>
  <div class="panel-body">
    

             <ul>
                 <li>ID : {{$package->id}}</li>
                 <li>Name : {{$package->name}}</li>
                 <li>Description : {{$package->description}}</li>
                 <li>Price : {{$package->price}}</li>
                 <li>Created Date : {{$package->created_at}}</li>
                 <li>Status : {{$package->status==1?"Active":"Inactive"}}</li>
               </ul>
             
                <img width="200" src="{{url('images/package/'.$package->image)}}" alt="{{$package->title}}" />


  </div>
  <div class="panel-footer">

     <a href="{{ route('package.edit', $package->id)}}" class="btn btn-primary">Edit Category</a>

</div>

@endsection