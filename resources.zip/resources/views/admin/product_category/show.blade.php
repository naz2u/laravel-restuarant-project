@extends('layouts.admin') ;

@section('content')


<h3><i class="fa fa-angle-right"></i> Category Details</h3>
        
<div class="panel panel-default">
  <div class="panel-heading">
      Category Name: {{$category->name}}
  </div>
  <div class="panel-body">
    

             <ul>
               <li>ID : {{$category->id}}</li>
               <li>Status : {{$category->status == 1? "active" : "inactive" }}</li>
               <li>Created Date : {{$category->created_at}}</li>
             </ul>


  </div>
  <div class="panel-footer">

     <a href="{{ route('product-category.edit', $category->id)}}" class="btn btn-primary">Edit Category</a>

</div>

@endsection