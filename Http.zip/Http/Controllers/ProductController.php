<?php
namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\ProductCategory;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = Product::all();
        return view('admin.products.index',compact(['product']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $category = ProductCategory::all();
         return view('admin.products.create',compact(['category']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $request->validate([
            'title' => 'required',
            'description' => 'required',
            'price' => 'required',
            'product_category_id' => 'required',
            'image' => 'required|file|mimes:jpg,jpeg,png'
        ]);

        $fileName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images/products'), $fileName);

        $data = $request->all();
        $data['status'] = $request->has('status')?1:0;
        $data['stockable'] = $request->has('stockable')?1:0;
        $data['image'] = $fileName;

        Product::create($data);

        return redirect('products')->with('success','New Product Created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $product = Product::find($id);
          return view('admin.products.show',compact(['product']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::find($id);
        $category = ProductCategory::all();
        return view('admin.products.edit',compact(['product','category']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
   public function update(Request $request, Product $product)
    {

         $request->validate([
            'title' => 'required',
            'description' => 'required',
            'price' => 'required',
            'product_category_id' => 'required',
            'image' => 'nullable|file|mimes:jpg,jpeg,png'
        ]);


      $data = $request->all();

     if($request->hasFile('image'))
     {
        $fileName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images/products'), $fileName);
        $data['image'] = $fileName;
     }else{        
        $data['image'] = $data['old_image'];
     }   

        $data['status'] = $request->has('status')?1:0;
        $data['stockable'] = $request->has('stockable')?1:0;


        $product->update($data);



        return redirect('products')->with('success','Product Updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Product::where('id',$id)->delete();
        return redirect('products')->with('success','Category Deleted!');
    }
}
