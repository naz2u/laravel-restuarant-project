@extends('layouts.admin') ;

@section('content')


        <h3><i class="fa fa-angle-right"></i> Update Product</h3>
          <div class="content-panel">

          <div class="panel panel-default">
            <div class="panel-body">


                 @if ($errors->any())
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                 @endif

            <div class="form-panel">
              <form class="form-horizontal style-form" action="{{route('package.update',$package->id)}}" method="POST"  enctype="multipart/form-data">

                @csrf

                @method('PUT')

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Name</label>
                  <div class="col-sm-10">
                    <input type="text" value="{{$package->name}}" class="form-control" name="title">                    
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">
                    <input type="text" value="{{$package->description}}" class="form-control" name="description">
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">price</label>
                  <div class="col-sm-10">
                    <input type="text" value="{{$package->price}}" class="form-control"  name="price">
                  </div>
                </div>


                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Products</label>
                  <div class="col-sm-10">

                    @foreach($package->products as $selected_products)
                      <input type="hidden"  name="old_products[]" value="{{$selected_products->id}}" >
                    @endforeach


                    @foreach($product as $products)
                      <input type="checkbox" class="pac_pt" name="products[]" value="{{$products->id}}" 

                        @foreach($package->products as $selected_products)
                          {{$selected_products->id == $products->id?'checked':''}}
                        @endforeach
                    
                      > {{$products->title}}
                    @endforeach

                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                    <input type="checkbox" name="status" value="1" 
                    {{$package->status == 1 ? ' checked' : ''}}> Active
                  </div>
                </div>                

               <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Image</label>
                  <div class="col-sm-10">

                    <input type="file" name="image" onchange="preview()" />

                    <input type="hidden" name="old_image" value="{{$package->image}}" />

                   <script type="text/javascript">
                        function preview() {
                          frame.src=URL.createObjectURL(event.target.files[0]);
                      }
                    </script>

                     <img id="frame" width="100" src="{{url('images/package/'.$package->image)}}" alt="{{$package->title}}" />
                  </div>
                </div>

                <button type="submit" class="btn btn-theme">Update</button>

              </form>
            </div>

            </div>
        
          </div>

          </div>


@endsection

