@extends('layouts.admin') ;

@section('content')


        <h3><i class="fa fa-angle-right"></i> Add New Package</h3>
          <div class="content-panel">

          <div class="panel panel-default">
            <div class="panel-body">


                 @if ($errors->any())
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                 @endif

            <div class="form-panel">
              <form class="form-horizontal style-form" action="{{route('package.store')}}" method="POST"  enctype="multipart/form-data">
                @csrf

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="name">
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" name="description"></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Price</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control"  name="price">
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Products</label>
                  <div class="col-sm-10">
                    
                    @foreach($product as $products)
                      <input type="checkbox" name="products[]" value="{{$products->id}}"/>
                      {{$products->title}}
                    @endforeach

                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                    <input type="checkbox" name="status" value="1"> Active
                  </div>
                </div>                

                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Image</label>
                  <div class="col-sm-10">
                    <input type="file" name="image" onchange="preview()"  >

                      <script type="text/javascript">
                        function preview() {
                          frame.src=URL.createObjectURL(event.target.files[0]);
                      }
                      </script>

                    <img src="" id="frame" width="150" />

                  </div>
                </div>

                <button type="submit" class="btn btn-theme">Create</button>

              </form>
            </div>

            </div>
        
          </div>

          </div>


@endsection

