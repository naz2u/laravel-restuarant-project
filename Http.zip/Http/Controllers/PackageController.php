<?php

namespace App\Http\Controllers;

use App\Models\Package;
use App\Models\Product;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $package = Package::all();
        return view ('admin.package.index',compact(['package']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $product = Product::all();
       return view('admin.package.create',compact(['product']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'price' => 'required',
            'image' => 'required|image|mimes:jpg,jpeg,png'
        ]);

        $fileName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images/package'), $fileName);

        $data = $request->all();
        $data['status'] = $request->has('status')?1:0;

        $data['image'] = $fileName;


        $products = $data['products'];

        $id = Package::create($data)->id;

        $package = Package::find($id);

        $package->products()->attach($products);

        return redirect('package')->with('success','New Package Created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
         $package = Package::find($id);
         return view('admin.package.show',compact(['package']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
         $package = Package::find($id);
         $product = Product::all();
        return view('admin.package.edit',compact(['package','product']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Package $package)
    {
        $request->validate([
            'name' => 'nullable',
            'description' => 'required',
            'price' => 'required',
            'image' => 'nullable|image|mimes:jpg,jpeg,png'
        ]);

    $data = $request->all();

     if($request->hasFile('image'))
     {
        $fileName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images/products'), $fileName);
        $data['image'] = $fileName;
     }else{        
        $data['image'] = $data['old_image'];
     }   
        $data['status'] = $request->has('status')?1:0;

        $package->update($data);
        

        $products = $data['products'];

        $id = $package->id;
        $package = Package::find($id);

        if($request->has('old_products')){
            $old_products = $data['old_products'];
            $package->products()->detach($old_products);
        }

        $package->products()->attach($products);


        return redirect('package')->with('success','Package Updated!');
    }

  
    public function destroy($id)
    {
        Package::where('id',$id)->delete();
        return redirect('package')->with('success','Package Deleted!');
    }
}
